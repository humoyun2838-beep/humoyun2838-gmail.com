# AI rasmlar

Built-in image_gen tool ishlatildi. Barcha rasmlar shu papkada PNG va Telegram uchun JPEG nusxalarida saqlangan.

## Avatar prompt

Create a polished square Telegram bot avatar for an Uzbek oncology and hematology staff reporting assistant named Onko gematalogiya. No text. Elegant teal and deep navy circular emblem, stylized crimson blood cell orbiting a gentle abstract medical care shield, subtle gold accent, restrained premium 3D illustration, clean simple silhouette legible at 48px, soft teal gradient background, trustworthy calm clinical design. No red cross emblem, no gore, no photos of patients.

## Sklad

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Sklad. Primary visual: orderly medicine storage shelves, sealed boxes and inventory clipboard. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Qabul bo‘limi

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Qabul bo‘limi. Primary visual: welcoming hospital reception doorway, clipboard and gentle care hands. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Transfuziologiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Transfuziologiya. Primary visual: blood bag and stylized red blood cells, non-graphic. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Oper blok

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Oper blok. Primary visual: surgical lamp above clean operating room and shield. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## OSS

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: OSS. Primary visual: sterile instrument trays and sterilization cabinet. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## 1-xirurgiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: 1-xirurgiya. Primary visual: surgical precision instruments and care shield, turquoise. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Neyronkologiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Neyronkologiya. Primary visual: luminous abstract brain with neural connections. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Poliklinika

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Poliklinika. Primary visual: stethoscope and friendly outpatient clinic facade. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## 1-gematologiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: 1-gematologiya. Primary visual: ruby red blood cell cluster, teal laboratory microscope. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Reanimatsiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Reanimatsiya. Primary visual: heart monitor with calm waveform and intensive care bed silhouette. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## 2-gematologiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: 2-gematologiya. Primary visual: abstract healthy blood cells and lavender laboratory flask. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## 2-xirurgiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: 2-xirurgiya. Primary visual: clean surgical instruments and navy care shield. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## 3-gematologiya

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: 3-gematologiya. Primary visual: blood cell constellation with cyan microscope. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Kunduzgi shifoxona

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Kunduzgi shifoxona. Primary visual: sunlit hospital window, day care chair and soft sun motif. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.

## Ximiya terapiya (4-gematologiya)

Use case: stylized-concept. Create ONE elegant wide landscape department welcome banner for an Uzbek oncology hematology hospital Telegram staff bot. Department: Ximiya terapiya (4-gematologiya). Primary visual: infusion bag beside comfortable care chair, hopeful abstract cells. Consistent premium restrained 3D medical illustration, deep navy and teal gradient background, soft rounded shapes, tiny warm gold accent, welcoming clean professional aesthetic. Main icon occupies right third, generous clean negative space on left, no text or letters, no numbers, no people or patient details, no gore, no red cross emblems, no watermark. This will appear above a department’s employee buttons. Beautiful but lightweight simple composition.
