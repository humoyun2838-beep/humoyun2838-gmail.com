"""Owner-only signed webhook diagnostic; prints timings, never credentials."""
import json, ssl, time, urllib.request
from pathlib import Path
v=dict(line.split('=',1) for line in Path('.env').read_text().splitlines() if '=' in line and not line.startswith('#'))
ctx=ssl.create_default_context(cafile='/etc/ssl/cert.pem')
for i,(route,text) in enumerate([('main','/start'),('main','Sklad'),('main','⬅️ Bo‘limlar'),('admin','/users')]):
 p={'update_id':int(time.time()*1000)+i,'message':{'from':{'id':int(v['ADMIN_IDS'].split(',')[0]),'first_name':'Nazarov'},'chat':{'id':int(v['ADMIN_IDS'].split(',')[0]),'type':'private'},'text':text}}
 request=urllib.request.Request(v['SHEETS_URL']+'?route='+route+'&key='+v['SHEETS_SECRET'],data=json.dumps(p).encode(),headers={'Content-Type':'application/json'})
 t=time.perf_counter()
 with urllib.request.urlopen(request,context=ctx,timeout=60) as response:
  body=response.read().decode(); ok='\\x22userHtml\\x22:\\x22OK' in body or 'OK' in body
 print(json.dumps({'route':route,'command':text,'seconds':round(time.perf_counter()-t,3),'acknowledged':ok},ensure_ascii=False),flush=True)
