"""Authenticated maintenance; emits report headers/counts only, never credentials."""
import argparse
import base64
import re
import json
import ssl
import urllib.error
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['audit', 'maintain', 'selftest'])
args = parser.parse_args()
values = dict(line.split('=', 1) for line in Path('.env').read_text().splitlines()
              if '=' in line and not line.startswith('#'))
request = urllib.request.Request(values['SHEETS_URL'],
    data=json.dumps({'secret': values['SHEETS_SECRET'], 'action': args.action}).encode(),
    headers={'Content-Type': 'application/json'})
context = ssl.create_default_context(cafile='/etc/ssl/cert.pem')
try:
    with urllib.request.urlopen(request, context=context, timeout=180) as response:
        body = response.read().decode()
        marker = re.search(r'ONKO_DIAGNOSTIC:([A-Za-z0-9_-]+):END_DIAGNOSTIC', body)
        if marker:
            encoded = marker.group(1)
            result = json.loads(base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4)))
        else:
            result = json.loads(body)
    print(json.dumps(result, ensure_ascii=False, indent=2))
except (TimeoutError, json.JSONDecodeError, urllib.error.URLError):
    print(json.dumps({'ok': False, 'error': 'Response not received; audit before retrying changes'}))
    raise SystemExit(1)
except urllib.error.HTTPError as error:
    print(json.dumps({'ok': False, 'http_status': error.code}))
    raise SystemExit(1)
