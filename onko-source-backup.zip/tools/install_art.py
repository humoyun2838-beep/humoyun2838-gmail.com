"""Install generated visuals using official Telegram Bot API; never prints bot tokens."""
import json, ssl, urllib.request, uuid
from pathlib import Path
v=dict(line.split('=',1) for line in Path('.env').read_text().splitlines() if '=' in line and not line.startswith('#'))
ctx=ssl.create_default_context(cafile='/etc/ssl/cert.pem')
def upload(token,method,fields,path,attachment='image'):
 boundary=uuid.uuid4().hex;parts=[]
 for k,value in fields.items():
  parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{value}\r\n'.encode())
 parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{attachment}"; filename="{path.name}"\r\nContent-Type: image/jpeg\r\n\r\n'.encode()+path.read_bytes()+b'\r\n')
 parts.append(f'--{boundary}--\r\n'.encode())
 req=urllib.request.Request('https://api.telegram.org/bot'+token+'/'+method,data=b''.join(parts),headers={'Content-Type':'multipart/form-data; boundary='+boundary})
 try:
  with urllib.request.urlopen(req,context=ctx,timeout=60) as r: result=json.load(r)
 except urllib.error.HTTPError as e:
  data=json.loads(e.read());raise RuntimeError(str(data.get('description','Upload failed'))) from None
 if not result.get('ok'):raise RuntimeError(result.get('description','Upload failed'))
 return result['result']
if __name__=='__main__':
 avatar=Path('assets/onko-avatar.jpg')
 for key in (() if '--skip-profile' in __import__('sys').argv else ('BOT_TOKEN','ADMIN_BOT_TOKEN')):
  upload(v[key],'setMyProfilePhoto',{'photo':json.dumps({'type':'static','photo':'attach://image'})},avatar)
  print(key.replace('_TOKEN','')+' profile image installed',flush=True)
 mapping={}
 for entry in json.loads(Path('assets/manifest.json').read_text()):
  result=upload(v['BOT_TOKEN'],'sendPhoto',{'chat_id':v['ADMIN_IDS'].split(',')[0],'caption':'🎨 '+entry['department'],'disable_notification':'true','photo':'attach://image'},Path(entry['jpg']))
  mapping[entry['department']]=result['photo'][-1]['file_id']
  print(entry['department']+' image installed',flush=True)
  # Remove only the temporary upload message, not any report.
  req=urllib.request.Request('https://api.telegram.org/bot'+v['BOT_TOKEN']+'/deleteMessage',data=json.dumps({'chat_id':v['ADMIN_IDS'].split(',')[0],'message_id':result['message_id']}).encode(),headers={'Content-Type':'application/json'})
  urllib.request.urlopen(req,context=ctx,timeout=30).read()
 Path('assets/telegram-art.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
 p=Path('hosted_bot.gs');s=p.read_text().replace('const DEPARTMENT_ART={};','const DEPARTMENT_ART='+json.dumps(mapping,ensure_ascii=False)+';');p.write_text(s)
