import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from bot import Bot
from admin_bot import AdminBot


class AdminTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.main = Bot('main', [1], 'url', 'secret', Path(self.tmp.name) / 'test.sqlite3')
        self.sent = []
        self.main.api = lambda method, **p: self.sent.append(('main', method, p)) or {}
        self.admin = AdminBot('admin', self.main)
        self.admin.api = lambda method, **p: self.sent.append(('admin', method, p)) or {}
        for uid in (1, 2, 3):
            self.main.db.execute('INSERT INTO profiles VALUES (?, ?, ?)', (uid, f'User {uid}', ''))
        self.main.save(1, 'approved', {})
        self.main.save(2, 'pending', {})

    def tearDown(self):
        self.main.db.close()
        self.tmp.cleanup()

    def callback(self, data, actor=1):
        self.admin.handle({'callback_query': {'id': 'q', 'from': {'id': actor},
                           'message': {'chat': {'type': 'private'}}, 'data': data}})

    def test_approve_revoke_and_restore(self):
        self.callback('approve:2')
        self.assertEqual(self.main.user(2)[0], 'approved')
        self.callback('revokeask:2')
        self.assertEqual(self.main.user(2)[0], 'approved')
        self.callback('revoke:2')
        self.assertEqual(self.main.user(2)[0], 'revoked')
        self.main.handle({'message': {'chat': {'type': 'private'}, 'from': {'id': 2}, 'text': 'Sklad'}})
        self.assertEqual(self.main.user(2)[1], {})
        self.callback('approve:2')
        self.assertEqual(self.main.user(2)[0], 'approved')

    def test_unauthorized_cannot_list_or_decide(self):
        self.callback('approve:2', 3)
        self.callback('list:users:0', 3)
        self.assertEqual(self.main.user(2)[0], 'pending')
        self.assertFalse(any(method == 'sendMessage' for _, method, _ in self.sent))

    def test_reject_stale_button_and_admin_protection(self):
        self.callback('reject:2')
        self.callback('reject:2')
        self.assertEqual(self.main.user(2)[0], 'rejected')
        self.callback('revoke:1')
        self.assertEqual(self.main.user(1)[0], 'approved')

    def test_notifications_only_once_and_paginated_listing(self):
        self.admin.notify_pending()
        self.admin.notify_pending()
        cards = [p for source, method, p in self.sent if source == 'admin' and method == 'sendMessage']
        self.assertEqual(len(cards), 1)
        for uid in range(10, 22):
            self.main.save(uid, 'approved', {})
            self.main.db.execute('INSERT INTO profiles VALUES (?, ?, ?)', (uid, f'User {uid}', ''))
        self.main.db.commit()
        self.admin.listing(1, 'users')
        buttons = self.sent[-1][2]['reply_markup']['inline_keyboard']
        self.assertEqual(len(buttons), 11)
        self.assertEqual(buttons[-1][0]['callback_data'], 'list:users:1')

    def test_main_routes_new_request_to_admin_database(self):
        with patch.dict('os.environ', {'ADMIN_BOT_TOKEN': 'admin'}):
            self.main.handle({'message': {'chat': {'type': 'private'},
                              'from': {'id': 3, 'first_name': 'New'}, 'text': '/start'}})
        self.assertEqual(self.main.user(3)[0], 'pending')
        self.assertFalse(any(p.get('chat_id') == 1 for _, _, p in self.sent))
        self.admin.notify_pending()
        self.assertTrue(any(source == 'admin' and p.get('chat_id') == 1 for source, _, p in self.sent))


if __name__ == '__main__':
    unittest.main()
